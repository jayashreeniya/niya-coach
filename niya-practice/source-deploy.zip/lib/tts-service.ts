import type { SupportedLanguage } from '@/types/database';
import type {
  TTSResponse,
  SSMLProsody,
  AzureOutputFormat,
} from '@/types/tts';
import {
  AZURE_VOICES,
  DEFAULT_PROSODY,
  DEFAULT_OUTPUT_FORMAT,
} from '@/types/tts';
import { getTTSCache, TTSCache } from './tts-cache';

const TTS_KEY = process.env.AZURE_TTS_KEY;
const TTS_REGION = process.env.AZURE_TTS_REGION || 'southindia';

// ---------------------------------------------------------------------------
// SSML generation
// ---------------------------------------------------------------------------

function escapeSSML(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function formatRate(rate: number): string {
  const pct = Math.round((rate - 1) * 100);
  return pct >= 0 ? `+${pct}%` : `${pct}%`;
}

/**
 * Split long text into sentence-level segments with SSML `<break>` tags.
 * This produces more natural yoga-teacher pacing with gentle pauses.
 */
function insertSentenceBreaks(text: string, breakMs: number = 600): string {
  const sentences = text.split(/(?<=[.!?])\s+/);
  if (sentences.length <= 1) return escapeSSML(text);

  return sentences
    .map((s) => escapeSSML(s.trim()))
    .filter(Boolean)
    .join(`<break time="${breakMs}ms"/> `);
}

export interface SSMLOptions {
  text: string;
  language: SupportedLanguage;
  voice?: string;
  prosody?: Partial<SSMLProsody>;
  sentenceBreakMs?: number;
}

/**
 * Build a complete SSML document for Azure Cognitive Services TTS.
 */
export function buildSSML(opts: SSMLOptions): string {
  const voiceInfo = AZURE_VOICES[opts.language];
  if (!voiceInfo) throw new Error(`Unsupported language: ${opts.language}`);

  const voiceId = opts.voice || voiceInfo.voice;
  const rate = formatRate(opts.prosody?.rate ?? DEFAULT_PROSODY.rate);
  const pitch = opts.prosody?.pitch ?? DEFAULT_PROSODY.pitch;
  const volume = opts.prosody?.volume ?? DEFAULT_PROSODY.volume;

  const textContent = insertSentenceBreaks(opts.text, opts.sentenceBreakMs);

  const prosodyAttrs = [
    `rate="${rate}"`,
    pitch ? `pitch="${pitch}"` : '',
    volume ? `volume="${volume}"` : '',
  ]
    .filter(Boolean)
    .join(' ');

  return [
    `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${voiceInfo.locale}">`,
    `  <voice name="${voiceId}">`,
    `    <prosody ${prosodyAttrs}>`,
    `      ${textContent}`,
    `    </prosody>`,
    `  </voice>`,
    `</speak>`,
  ].join('\n');
}

// ---------------------------------------------------------------------------
// Azure TTS REST API
// ---------------------------------------------------------------------------

async function callAzureTTS(
  ssml: string,
  format: AzureOutputFormat = DEFAULT_OUTPUT_FORMAT
): Promise<ArrayBuffer> {
  if (!TTS_KEY) throw new Error('AZURE_TTS_KEY not configured');

  const endpoint = `https://${TTS_REGION}.tts.speech.microsoft.com/cognitiveservices/v1`;

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Ocp-Apim-Subscription-Key': TTS_KEY,
      'Content-Type': 'application/ssml+xml',
      'X-Microsoft-OutputFormat': format,
    },
    body: ssml,
  });

  if (!response.ok) {
    const details = await response.text();
    const err = new Error(`Azure TTS failed (${response.status})`) as Error & {
      azureStatus: number;
      details: string;
    };
    err.azureStatus = response.status;
    err.details = details;
    throw err;
  }

  return response.arrayBuffer();
}

// ---------------------------------------------------------------------------
// Duration estimation
// ---------------------------------------------------------------------------

/** Rough MP3 duration estimate from base64 string length (48kbps mono) */
function estimateDurationSeconds(base64: string): number {
  const byteSize = (base64.length * 3) / 4;
  // 48kbps = 6000 bytes/sec
  return byteSize / 6000;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface SynthesizeOptions {
  text: string;
  language: SupportedLanguage;
  voice?: string;
  speed?: number;
  pitch?: string;
  volume?: string;
  sentenceBreakMs?: number;
  /** Bypass the cache for this request */
  skipCache?: boolean;
}

/**
 * Synthesize speech for a single text block.
 * Returns a base64 data-URI and metadata. Results are cached by default.
 */
export async function synthesize(opts: SynthesizeOptions): Promise<TTSResponse> {
  const voiceInfo = AZURE_VOICES[opts.language];
  if (!voiceInfo) throw new Error(`Unsupported language: ${opts.language}`);

  const voiceId = opts.voice || voiceInfo.voice;
  const speed = opts.speed ?? DEFAULT_PROSODY.rate;
  const cache = getTTSCache();

  const cacheKey = TTSCache.buildKey({
    text: opts.text,
    voice: voiceId,
    speed,
    pitch: opts.pitch,
    volume: opts.volume,
  });

  if (!opts.skipCache) {
    const cached = cache.get(cacheKey);
    if (cached) {
      return {
        audioUrl: `data:audio/mp3;base64,${cached}`,
        duration: estimateDurationSeconds(cached),
        voice: voiceId,
        format: DEFAULT_OUTPUT_FORMAT,
      };
    }
  }

  const ssml = buildSSML({
    text: opts.text,
    language: opts.language,
    voice: voiceId,
    prosody: { rate: speed, pitch: opts.pitch, volume: opts.volume },
    sentenceBreakMs: opts.sentenceBreakMs,
  });

  const audioBuffer = await callAzureTTS(ssml);
  const base64 = Buffer.from(audioBuffer).toString('base64');

  cache.set(cacheKey, base64, voiceId);

  return {
    audioUrl: `data:audio/mp3;base64,${base64}`,
    duration: estimateDurationSeconds(base64),
    voice: voiceId,
    format: DEFAULT_OUTPUT_FORMAT,
  };
}

/**
 * Pre-generate audio for every step of a practice in parallel.
 * Populates the server cache so playback has no inter-step delay.
 */
export async function synthesizeAllSteps(
  steps: { text: string; pause_after?: number }[],
  language: SupportedLanguage,
  speed?: number
): Promise<TTSResponse[]> {
  return Promise.all(
    steps.map((step) =>
      synthesize({ text: step.text, language, speed })
    )
  );
}

/** Whether Azure TTS credentials are present */
export function isTTSConfigured(): boolean {
  return !!TTS_KEY;
}

/** Return server-side cache metrics for health/monitoring */
export function getCacheStats() {
  return getTTSCache().stats();
}
