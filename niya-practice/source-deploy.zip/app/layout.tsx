import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import { AuthProvider } from '@/components/auth/AuthProvider';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'NIYA Practice — 90-Day Emotional Fitness',
  description:
    'Build lasting emotional resilience through guided daily practices with soothing audio guidance in English, Hindi, Tamil, and Telugu.',
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_APP_URL || 'https://practice.niya.app'
  ),
  openGraph: {
    title: 'NIYA Practice',
    description: '90-Day Emotional Fitness Journey with Audio Guidance',
    siteName: 'NIYA Practice',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#9333ea',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
