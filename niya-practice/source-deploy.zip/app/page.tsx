import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { LoginButton } from '@/components/auth/LoginButton';
import { AppFooter } from '@/components/integration/AppFooter';

export default async function LandingPage() {
  const user = await getCurrentUser();
  if (user) redirect('/practice');

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-purple-50 via-white to-blue-50">
    <main className="flex flex-1 flex-col items-center justify-center px-4">
      {/* Hero */}
      <div className="text-center mb-10 max-w-lg">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl shadow-lg mb-6">
          <span className="text-4xl">🧘</span>
        </div>

        <h1 className="text-4xl font-bold text-gray-900 mb-3 text-balance">
          NIYA Practice
        </h1>

        <p className="text-lg text-gray-600 leading-relaxed mb-2">
          90-Day Emotional Fitness Journey
        </p>

        <p className="text-sm text-gray-500 leading-relaxed">
          Build lasting emotional resilience with guided daily practices.
          Choose audio guidance in English, Hindi, Tamil, or Telugu &mdash;
          with soothing, yoga-teacher pacing.
        </p>
      </div>

      {/* Feature pills */}
      <div className="flex flex-wrap justify-center gap-2 mb-10 max-w-md">
        {[
          { icon: '🎧', label: 'Audio Guided' },
          { icon: '📖', label: 'Text Mode' },
          { icon: '🔥', label: 'Streak Tracking' },
          { icon: '📊', label: 'Emotional Score' },
          { icon: '🌏', label: '4 Languages' },
        ].map((f) => (
          <span
            key={f.label}
            className="inline-flex items-center gap-1.5 bg-white/80 border border-purple-100 text-gray-700 text-xs font-medium px-3 py-1.5 rounded-full shadow-sm"
          >
            <span>{f.icon}</span>
            {f.label}
          </span>
        ))}
      </div>

      {/* Login */}
      <LoginButton />

      {/* Terms */}
      <p className="mt-12 text-xs text-gray-400">
        By continuing you agree to NIYA&apos;s Terms of Service and Privacy
        Policy.
      </p>
    </main>
    <AppFooter />
    </div>
  );
}
