import { NextResponse } from 'next/server';
import { healthCheck } from '@/lib/db';
import { isTTSConfigured } from '@/lib/tts-service';
import type { HealthCheckResponse } from '@/types/api';

export async function GET() {
  const db = await healthCheck();
  const ttsConfigured = isTTSConfigured();

  const status = db.ok ? (ttsConfigured ? 'ok' : 'degraded') : 'down';

  const response: HealthCheckResponse = {
    status,
    database: { ok: db.ok, latencyMs: db.latencyMs },
    tts: { configured: ttsConfigured },
    timestamp: new Date().toISOString(),
  };

  return NextResponse.json(response, {
    status: status === 'down' ? 503 : 200,
  });
}
