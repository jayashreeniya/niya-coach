import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import type { TTSRequest, TTSResponse, TTSError } from '@/types/tts';
import { AZURE_VOICES } from '@/types/tts';
import { synthesize, isTTSConfigured } from '@/lib/tts-service';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json<TTSError>({ error: 'Unauthorized' }, { status: 401 });
  }

  if (!isTTSConfigured()) {
    return NextResponse.json<TTSError>(
      { error: 'TTS not configured' },
      { status: 503 }
    );
  }

  let body: TTSRequest;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json<TTSError>({ error: 'Invalid JSON' }, { status: 400 });
  }
  const { text, language, voice, speed, prosody } = body;

  if (!text || !language) {
    return NextResponse.json<TTSError>(
      { error: 'Missing text or language' },
      { status: 400 }
    );
  }

  if (!AZURE_VOICES[language]) {
    return NextResponse.json<TTSError>(
      { error: `Unsupported language: ${language}` },
      { status: 400 }
    );
  }

  try {
    const result = await synthesize({
      text,
      language,
      voice,
      speed,
      pitch: prosody?.pitch,
      volume: prosody?.volume,
    });

    return NextResponse.json<TTSResponse>(result);
  } catch (error: any) {
    console.error('TTS error:', error);
    return NextResponse.json<TTSError>(
      {
        error: 'TTS generation failed',
        details: error.details,
        azureStatus: error.azureStatus,
      },
      { status: error.azureStatus || 500 }
    );
  }
}
