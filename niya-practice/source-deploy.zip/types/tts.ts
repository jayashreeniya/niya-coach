import type { SupportedLanguage } from './database';

// ---------------------------------------------------------------------------
// Azure voice definitions
// ---------------------------------------------------------------------------

export interface TTSVoice {
  language: SupportedLanguage;
  /** Localised language name for UI display */
  languageName: string;
  /** Azure Cognitive Services voice identifier (Neural voices only) */
  voice: string;
  /** Short localised description shown under the language selector */
  description: string;
  /** BCP-47 locale tag used in SSML xml:lang attribute */
  locale: string;
}

export const AZURE_VOICES: Record<SupportedLanguage, TTSVoice> = {
  en: {
    language: 'en',
    languageName: 'English',
    voice: 'en-IN-NeerjaNeural',
    description: 'Soothing Indian accent',
    locale: 'en-IN',
  },
  hi: {
    language: 'hi',
    languageName: 'हिंदी',
    voice: 'hi-IN-SwaraNeural',
    description: 'शांत महिला स्वर',
    locale: 'hi-IN',
  },
  ta: {
    language: 'ta',
    languageName: 'தமிழ்',
    voice: 'ta-IN-PallaviNeural',
    description: 'அமைதியான பெண் குரல்',
    locale: 'ta-IN',
  },
  te: {
    language: 'te',
    languageName: 'తెలుగు',
    voice: 'te-IN-ShrutiNeural',
    description: 'శాంతమైన మహిళ స్వరం',
    locale: 'te-IN',
  },
};

// ---------------------------------------------------------------------------
// SSML configuration
// ---------------------------------------------------------------------------

/** Prosody settings that shape the yoga-teacher audio pacing */
export interface SSMLProsody {
  /** Speech rate relative to normal: 0.75 = 25% slower (default yoga pace) */
  rate: number;
  /** Pitch adjustment in Hz or semitones, e.g. '-2st' for warmer tone */
  pitch?: string;
  /** Volume: 'soft', 'medium', 'loud', or dB like '+6dB' */
  volume?: string;
}

export const DEFAULT_PROSODY: SSMLProsody = {
  rate: 0.75,
  pitch: '-1st',
  volume: 'medium',
};

/** Silence break inserted between SSML segments */
export interface SSMLBreak {
  /** Duration in milliseconds */
  timeMs: number;
  /** Break strength hint for the engine */
  strength?: 'none' | 'x-weak' | 'weak' | 'medium' | 'strong' | 'x-strong';
}

/**
 * Supported Azure output formats.
 * We default to 24kHz mono MP3 for a good quality / size balance.
 */
export type AzureOutputFormat =
  | 'audio-16khz-32kbitrate-mono-mp3'
  | 'audio-24khz-48kbitrate-mono-mp3'
  | 'audio-24khz-96kbitrate-mono-mp3'
  | 'audio-48khz-96kbitrate-mono-mp3'
  | 'ogg-24khz-16bit-mono-opus'
  | 'webm-24khz-16bit-mono-opus';

export const DEFAULT_OUTPUT_FORMAT: AzureOutputFormat =
  'audio-24khz-48kbitrate-mono-mp3';

// ---------------------------------------------------------------------------
// API request / response for /api/tts
// ---------------------------------------------------------------------------

export interface TTSRequest {
  text: string;
  language: SupportedLanguage;
  /** If omitted, the default voice for the language is used */
  voice?: string;
  /** 0.75 = slower yoga pace (default), 1.0 = normal */
  speed?: number;
  /** Optional prosody overrides (pitch, volume) */
  prosody?: Partial<Omit<SSMLProsody, 'rate'>>;
}

export interface TTSResponse {
  /** Base64 data-URI of the generated audio */
  audioUrl: string;
  /** Estimated duration in seconds (derived from byte size) */
  duration: number;
  /** The voice identifier that was actually used */
  voice: string;
  /** The output format used */
  format: AzureOutputFormat;
}

export interface TTSError {
  error: string;
  details?: string;
  /** HTTP status from Azure TTS, if available */
  azureStatus?: number;
}

// ---------------------------------------------------------------------------
// Client-side audio playback state
// ---------------------------------------------------------------------------

export type AudioPlaybackStatus =
  | 'idle'
  | 'loading'
  | 'playing'
  | 'paused'
  | 'waiting'
  | 'error'
  | 'complete';

export interface AudioPlaybackState {
  status: AudioPlaybackStatus;
  /** 0-1 progress through the current audio clip */
  progress: number;
  /** Current playback time in seconds */
  currentTime: number;
  /** Total duration in seconds (available after metadata load) */
  duration: number;
  /** The step index currently being played (0-based) */
  currentStepIndex: number;
  /** Error message if status is 'error' */
  errorMessage?: string;
}

export const INITIAL_PLAYBACK_STATE: AudioPlaybackState = {
  status: 'idle',
  progress: 0,
  currentTime: 0,
  duration: 0,
  currentStepIndex: 0,
};

/**
 * Audio player controls returned by the useAudioPlayer hook.
 * Separated from state so consumers can destructure cleanly.
 */
export interface AudioPlayerControls {
  playStep: (text: string, pauseAfter?: number) => Promise<void>;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  /** Seek to a 0-1 position within the current clip */
  seekTo: (position: number) => void;
}

// ---------------------------------------------------------------------------
// Step-level audio tracking (for analytics)
// ---------------------------------------------------------------------------

/** Emitted when a single step's audio playback finishes */
export interface StepAudioEvent {
  stepIndex: number;
  stepTitle: string;
  language: SupportedLanguage;
  voice: string;
  /** Actual playback duration in seconds (may differ from step.duration_seconds) */
  playbackDuration: number;
  /** Whether the user paused during this step */
  wasPaused: boolean;
  /** Whether the user skipped this step */
  wasSkipped: boolean;
}
