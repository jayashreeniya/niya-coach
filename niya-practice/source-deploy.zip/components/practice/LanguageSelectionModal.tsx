'use client';

import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import { AZURE_VOICES } from '@/types/tts';
import type { SupportedLanguage } from '@/types/database';

interface LanguageSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (language: SupportedLanguage) => void;
  defaultLanguage?: SupportedLanguage;
}

const LANGUAGES = [
  {
    code: 'en' as const,
    nativeName: 'English',
    flag: '🇬🇧',
    voice: AZURE_VOICES.en,
    sample: 'Find a comfortable position...',
  },
  {
    code: 'hi' as const,
    nativeName: 'हिंदी',
    flag: '🇮🇳',
    voice: AZURE_VOICES.hi,
    sample: 'एक आरामदायक स्थिति खोजें...',
  },
  {
    code: 'ta' as const,
    nativeName: 'தமிழ்',
    flag: '🇮🇳',
    voice: AZURE_VOICES.ta,
    sample: 'வசதியான நிலையைக் கண்டறியவும்...',
  },
  {
    code: 'te' as const,
    nativeName: 'తెలుగు',
    flag: '🇮🇳',
    voice: AZURE_VOICES.te,
    sample: 'సౌకర్యవంతమైన స్థానాన్ని కనుగొనండి...',
  },
];

export function LanguageSelectionModal({
  isOpen,
  onClose,
  onSelect,
  defaultLanguage = 'en',
}: LanguageSelectionModalProps) {
  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 shadow-2xl transition-all">
                <div className="mb-6">
                  <Dialog.Title
                    as="h3"
                    className="text-2xl font-bold text-gray-900 mb-2"
                  >
                    Choose Your Language
                  </Dialog.Title>
                  <p className="text-sm text-gray-600">
                    Select the language for your audio-guided practice
                  </p>
                </div>

                <div className="space-y-3 mb-6">
                  {LANGUAGES.map((lang) => {
                    const isDefault = lang.code === defaultLanguage;

                    return (
                      <button
                        key={lang.code}
                        onClick={() => onSelect(lang.code)}
                        className={`w-full flex items-center gap-4 p-4 border-2 rounded-xl transition-all group hover:scale-[1.02] active:scale-[0.98] ${
                          isDefault
                            ? 'border-purple-500 bg-purple-50'
                            : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50'
                        }`}
                      >
                        <span className="text-4xl">{lang.flag}</span>
                        <div className="flex-1 text-left">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-gray-900 group-hover:text-purple-700">
                              {lang.nativeName}
                            </span>
                            {isDefault && (
                              <span className="text-xs bg-purple-500 text-white px-2 py-0.5 rounded-full">
                                Default
                              </span>
                            )}
                          </div>
                          <div className="text-sm text-gray-600 mt-0.5">
                            {lang.voice.description}
                          </div>
                          <div className="text-xs text-gray-400 mt-1 italic">
                            &ldquo;{lang.sample}&rdquo;
                          </div>
                        </div>
                        <svg
                          className="w-5 h-5 text-gray-400 group-hover:text-purple-500"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </button>
                    );
                  })}
                </div>

                <button
                  onClick={onClose}
                  className="w-full py-3 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
