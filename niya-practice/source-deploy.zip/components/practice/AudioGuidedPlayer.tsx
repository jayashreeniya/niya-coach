'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { usePracticeAudio } from '@/hooks/usePracticeAudio';
import { AZURE_VOICES } from '@/types/tts';
import type { Practice, SupportedLanguage } from '@/types/database';

interface AudioGuidedPlayerProps {
  practice: Practice;
  userId: number;
  language: SupportedLanguage;
}

export function AudioGuidedPlayer({
  practice,
  userId,
  language,
}: AudioGuidedPlayerProps) {
  const router = useRouter();
  const [hasStarted, setHasStarted] = useState(false);
  const voiceInfo = AZURE_VOICES[language];

  const audio = usePracticeAudio({
    steps: practice.instructions,
    language,
    onStepComplete: () => {},
    onAllStepsComplete: () => {
      router.push(
        `/complete?practice=${practice.id}&mode=audio&lang=${language}`
      );
    },
    enabled: true,
  });

  const currentStep = practice.instructions[audio.state.currentStepIndex];
  const isLastStep =
    audio.state.currentStepIndex === practice.instructions.length - 1;
  const isPlaying = audio.state.status === 'playing';
  const isPaused = audio.state.status === 'paused';
  const isLoading = audio.state.status === 'loading';

  useEffect(() => {
    if (!hasStarted) {
      setHasStarted(true);
      audio.play(0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleExit = () => {
    if (confirm('Are you sure you want to exit? Your progress will not be saved.')) {
      audio.stop();
      router.push('/practice');
    }
  };

  const overallProgress =
    ((audio.state.currentStepIndex + audio.state.progress) /
      practice.instructions.length) *
    100;

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 via-blue-50 to-white">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-purple-100 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <button
          onClick={handleExit}
          className="text-gray-600 hover:text-gray-900 flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          <span className="font-medium">Exit</span>
        </button>

        <div className="text-center">
          <h2 className="font-semibold text-gray-900">{practice.title}</h2>
          <p className="text-xs text-gray-500">
            🎧 {voiceInfo.languageName} &middot; Audio Guided
          </p>
        </div>

        <div className="w-16" />
      </div>

      {/* Progress */}
      <div className="w-full bg-purple-100 h-1.5">
        <div
          className="bg-gradient-to-r from-purple-500 to-blue-500 h-1.5 transition-all duration-300"
          style={{ width: `${overallProgress}%` }}
        />
      </div>

      {/* Main */}
      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Step counter */}
        <div className="text-center mb-6">
          <p className="text-sm text-purple-600 font-medium mb-1">
            Step {audio.state.currentStepIndex + 1} of{' '}
            {practice.instructions.length}
          </p>
          <h1 className="text-3xl font-bold text-gray-900">
            {currentStep?.title}
          </h1>
        </div>

        {/* Audio visualization orb */}
        <div className="flex justify-center mb-8">
          <div className={`relative ${isPlaying ? 'animate-pulse-slow' : ''}`}>
            <div className="w-48 h-48 rounded-full bg-gradient-to-br from-purple-200 to-blue-200 flex items-center justify-center">
              <div className="w-36 h-36 rounded-full bg-gradient-to-br from-purple-400 to-blue-400 flex items-center justify-center">
                <div className="text-white">
                  {isLoading ? (
                    <svg className="w-16 h-16 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  ) : isPaused ? (
                    <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                    </svg>
                  ) : (
                    <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  )}
                </div>
              </div>
            </div>

            {isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-56 h-56 rounded-full border-4 border-purple-300/30 animate-ping-slow" />
                <div className="absolute w-64 h-64 rounded-full border-4 border-blue-300/20 animate-ping-slower" />
              </div>
            )}
          </div>
        </div>

        {/* Audio source & pause badge */}
        <div className="flex justify-center gap-2 mb-4">
          {audio.state.source === 'browser' && (
            <span className="text-xs text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full">
              Using browser voice (Azure unavailable)
            </span>
          )}
          {audio.state.status === 'waiting' && audio.state.pauseCountdown > 0 && (
            <span className="text-xs text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
              Silence &middot; {audio.state.pauseCountdown}s
            </span>
          )}
        </div>

        {/* Practice text */}
        {currentStep && (
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl shadow-lg p-8 mb-8 border border-purple-100">
            <p className="text-lg text-gray-700 leading-relaxed text-center">
              {currentStep.text}
            </p>
          </div>
        )}

        {/* Controls */}
        <div className="flex flex-col items-center gap-4">
          <button
            onClick={isPaused ? audio.resume : audio.pause}
            disabled={isLoading}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:from-gray-300 disabled:to-gray-400 text-white font-semibold px-12 py-4 rounded-full shadow-lg transition-all transform hover:scale-105 active:scale-95 disabled:transform-none disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <svg className="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Loading...
              </span>
            ) : isPaused ? (
              <span className="flex items-center gap-2">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                Resume
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" /></svg>
                Pause
              </span>
            )}
          </button>

          {!isLastStep && (
            <button
              onClick={audio.skipStep}
              disabled={isLoading}
              className="text-gray-600 hover:text-gray-900 font-medium px-6 py-2 rounded-full hover:bg-gray-100 transition-all disabled:opacity-50"
            >
              Skip this step &rarr;
            </button>
          )}
        </div>

        {/* Tips */}
        <div className="mt-12 text-center text-sm text-gray-500 space-y-2">
          <p>🎧 Listen with headphones for the best experience</p>
          <p>🧘 Follow along with the gentle guidance</p>
          <p>⏸️ Pause anytime if you need a moment</p>
        </div>

        {/* Error */}
        {audio.state.status === 'error' && (
          <div className="mt-6 text-center">
            <p className="text-sm text-red-600 bg-red-50 rounded-lg px-4 py-3">
              {audio.state.errorMessage}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
