module BxBlockCalendar
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
