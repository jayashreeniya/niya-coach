module BxBlockVideocall5
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
