module BxBlockLogin
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
