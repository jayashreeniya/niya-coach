module BxBlockAddress
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
