module BxBlockChatbot6
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
