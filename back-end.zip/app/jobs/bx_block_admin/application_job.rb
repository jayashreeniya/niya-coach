module BxBlockAdmin
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
