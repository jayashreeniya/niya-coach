module BxBlockLandingpage3
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
