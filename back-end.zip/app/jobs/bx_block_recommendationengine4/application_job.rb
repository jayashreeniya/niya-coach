module BxBlockRecommendationengine4
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
