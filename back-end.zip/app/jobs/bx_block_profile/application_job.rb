module BxBlockProfile
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
