module BxBlockTimetrackingbilling
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
