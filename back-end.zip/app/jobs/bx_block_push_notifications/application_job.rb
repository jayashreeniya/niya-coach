module BxBlockPushNotifications
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
