module BxBlockTargetedfeed
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
