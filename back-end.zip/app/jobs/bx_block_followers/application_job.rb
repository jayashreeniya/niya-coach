module BxBlockFollowers
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
