module BxBlockInteractiveFaqs
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
