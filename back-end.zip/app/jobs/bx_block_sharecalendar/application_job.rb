module BxBlockSharecalendar
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
