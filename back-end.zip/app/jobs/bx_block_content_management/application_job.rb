module BxBlockContentManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
