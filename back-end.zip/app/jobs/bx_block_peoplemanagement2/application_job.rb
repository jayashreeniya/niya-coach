module BxBlockPeoplemanagement2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
