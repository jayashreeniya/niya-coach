module BxBlockQuestionbank
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
