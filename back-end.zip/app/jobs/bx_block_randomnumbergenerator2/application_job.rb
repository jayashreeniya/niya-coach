module BxBlockRandomnumbergenerator2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
