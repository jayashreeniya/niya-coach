module BxBlockChat
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
