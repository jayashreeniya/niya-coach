module BxBlockForgotPassword
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
