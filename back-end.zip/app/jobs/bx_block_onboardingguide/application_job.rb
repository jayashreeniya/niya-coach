module BxBlockOnboardingguide
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
