module BxBlockContentManagement
  module BuildRole
    class << self
    end
  end
end
