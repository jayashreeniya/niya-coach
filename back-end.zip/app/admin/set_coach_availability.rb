ActiveAdmin.register AccountBlock::Account, as: "coach_availability" do
  # menu priority: 5
 # index label: 'Label 1'
  config.batch_actions = false
  menu label: "Coach Availability"
  actions :all, except: [:new,:destroy]
  DATE = "dd/mm/yy"
  DAYS = Date::DAYNAMES
  Start_date = "Start Date"
  End_date = "End Date"
  
  permit_params :full_name, :email, :full_phone_number, :password, :password_confirmation, :access_code, :activated,:city, :education, expertise: [], user_languages_attributes: [:id, :language, :_destroy], coach_leaves_attributes: [:start_date, :end_date], coach_par_avails_attributes: [:start_date, :end_date, :avail_type, coach_par_times_attributes: [:from, :to, :booked_slot, :sno, :_destroy],week_days: []] 

  filter :full_name, as: :string, label: "Full Name"
  filter :email, as: :string, label: "Email"
  filter :full_phone_number

  after_update :check_activation

  controller do 
  	def scoped_collection
      @accounts = AccountBlock::Account.where(role_id: BxBlockRolesPermissions::Role.find_by_name(BxBlockRolesPermissions::Role.names[:coach]).id)
    end

  	def update
  		begin
  	  params["account"]["coach_par_avails_attributes"]["0"]["week_days"].reject!(&:empty?)
      params["account"]["coach_par_avails_attributes"]["1"]["week_days"].reject!(&:empty?)
  	  params["account"]["coach_par_avails_attributes"]["2"]["week_days"] = [params["account"]["coach_par_avails_attributes"]["2"]["week_days"]]
      return render json: { error: "please select diferrent value between available time and unavailable time"} if params["account"]["coach_par_avails_attributes"]["0"] == params["account"]["coach_par_avails_attributes"]["1"] && params["account"]["coach_par_avails_attributes"]["0"]['start_date'].present?
      role_id = BxBlockRolesPermissions::Role.find_by_name(:coach).id
      account = AccountBlock::Account.find_by(id: params['id'], role_id: role_id)
      params['account']['coach_leaves_attributes'].each do |leave|
      	# coach_off = BxBlockAppointmentManagement::CoachLeave.new(account_id: account.id, start_date: leave.first['start_date'] )
        coach_off = BxBlockAppointmentManagement::CoachLeave.new(account_id: account.id, start_date: leave.second['start_date'], end_date: leave.second['end_date'])
      	coach_off.save!
      end if params['account']['coach_leaves_attributes']['0']['start_date'].present?
        start_date = []
        params['account']['coach_par_avails_attributes']&.each do |avl| 
          avail = BxBlockAppointmentManagement::CoachParAvail.new(start_date: avl.second['start_date'], end_date: avl.second['end_date'], week_days: avl.second['week_days'], account_id: account.id)
          avail.avail_type = "unavailable" if params['account']['coach_par_avails_attributes']['1'] == avl.second
          avail.save! 
            avl.second['coach_par_times_attributes']&.each do |sub|
              avail_time = BxBlockAppointmentManagement::AvailableTime.new(from: sub.second['from(4i)']+ ":" + sub.second['from(5i)'], to: sub.second['to(4i)']+ ":" + sub.second['to(5i)'], coach_par_avail_id: avail.id)
              avail_time.save!
            end if avl.second['start_date'].present?
        end if params['account']['coach_par_avails_attributes']['0']&.present?
      account.save

      redirect_to admin_coach_availabilities_path  and return
  	  rescue Exception => e
  		render json: { error: "#{e}" }
  	  end
  	end

  end

  index :download_links => false do 
	    selectable_column
	    id_column
	    column :full_name
	    column :email
	    column :full_phone_number
	    column :activated
	    column :created_at
	    column :updated_at
	    actions
  end

  show do
    attributes_table title: "Account Details" do
      row :full_name
      row :email 
      row :full_phone_number
      row :created_at
      row :updated_at
    end
  end

  form title: "Edit Coach Availability" do |f|
    f.inputs do
      def coach_par_avails_section(form, heading, heading2, type, hint)
         para hint
        form.has_many :coach_par_avails, for: [:coach_par_avails, BxBlockAppointmentManagement::CoachParAvail.new], heading: heading do |t| 
            t.input :start_date,label: Start_date,as: :datepicker, datepicker_options: { dateFormat: DATE }
            t.input :end_date,label: End_date,as: :datepicker, datepicker_options: { dateFormat: DATE }
            t.input :week_days,label: "Week Days", as: :check_boxes,  collection: DAYS, include_blank: false,  multiple: true  if type.blank?
            t.input :week_days,label: "Week Day", as: :select,  collection: DAYS, include_blank: false  if type.present?
             coach_par_times_section(t, heading2 )
           end
      end

      def coach_par_times_section(form, heading)
        new_record_label = heading == "Coach Unavailable Time" ? "Add new unavailable time" : "Add new available time"
      
        form.has_many :coach_par_times, for: [:coach_par_times, BxBlockAppointmentManagement::AvailableTime.new], heading: heading, new_record: new_record_label do |c_p|
          c_p.input :from, as: :time_select, ignore_date: true, start_hour: 6, end_hour: 23, minute_step: 15, include_blank: false
          c_p.input :to, as: :time_select, ignore_date: true, start_hour: 7, end_hour: 23, minute_step: 15, include_blank: false
        end
      end
  		f.has_many :coach_leaves,for: [:coach_leaves, BxBlockAppointmentManagement::CoachLeave.new], allow_destroy: true, heading: "COACH LEAVE" do |t|
          t.input :start_date,label: Start_date, as: :datepicker, datepicker_options: { dateFormat: DATE }
          t.input :end_date,label: End_date,hint: "If you want to take leave of one day, then 'Start date', and 'End date' should be same.", as: :datepicker, datepicker_options: { dateFormat: DATE }

        end

          # ----------create coach available time----------

          hint = "Note: 'SET COACH AVAILABILITY' form for set availability for a coach on multiple days of the week between given dates."
        coach_par_avails_section(f, "SET COACH AVAILABILITY", "Coach Available Time", "", hint)

      # ----------update coach unavailable time----------

        coach_par_avails_section(f, "UPDATE UNAVAILABLE TIME", "Coach Unavailable Time", "", "Note: 'UPDATE UNAVAILABLE TIME' form for set unavailable time for a coach on multiple days of the week between given dates." )

  		# ----------update coach available time----------

        coach_par_avails_section(f, "UPDATE COACH AVAILABILITY", "Available Time", "update", "Note: 'UPDATE COACH AVAILABILITY' form for set coach availability timings for a particular day of the week between a given range of dates.")

      end
      f.actions do
        f.submit "Submit"
   	  end
  	end
end