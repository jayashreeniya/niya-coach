module BxBlockContactUs
  class MotionSerializer < BuilderBase::BaseSerializer
    attributes *[
      :motion_title
        
    ]    
  end
end

