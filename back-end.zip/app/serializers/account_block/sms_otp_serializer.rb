module AccountBlock
  class SmsOtpSerializer < BuilderBase::BaseSerializer
  end
end
