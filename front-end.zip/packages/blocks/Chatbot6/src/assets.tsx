export const imgPasswordVisible = require("../assets/ic_password_visible.png");
export const imgPasswordInVisible = require("../assets/ic_password_invisible.png");

export const SendBtn=require('../assets/sendbtn.png');
export const backImg=require('../assets/black_back.png');
export const bgImg=require('../assets/Group.png');
export const checkBoxImg = require("../assets/check.png");
export const unCheckBoxIMg= require("../assets/uncheck.png");
export const niyaChatBoxIMgHeader= require("../assets/niyaheaderchat.png");
export const niyaImg=require('../assets/niyawhale.png');
export const niya1Img=require('../assets/niya1.png');