export const imgPasswordVisible = require("../assets/passwordvisibleicon.png");
export const imgPasswordInVisible = require("../assets/eye-slashgry.png");
export const bgPassImg =require('../assets/viv.png');
export const bgNiyaEMAILImg =require('../assets/niyastar.png');
export const bgEnterMobileImg =require('../assets/mobileheader.png');
export const enterMobileNoOtpImg =require('../assets/mobileotp.png');
export const enterNewPassImg =require('../assets/CretePass.png');
export const passCreatedSuccessfully=require('../assets/passcreted.png')
