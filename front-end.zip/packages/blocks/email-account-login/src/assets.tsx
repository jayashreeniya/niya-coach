export const imgPasswordVisible = require("../assets/passwordvisibleicon.png");
export const imgPasswordInVisible = require("../assets/eyeslash.png");