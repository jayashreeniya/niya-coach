export default {
    openPicker: jest.fn().mockImplementation(() => Promise.resolve())
  };