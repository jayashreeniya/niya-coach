## Building Blocks React Native Mobile -  ShareCalendar

Building Blocks - React Native Master App - ShareCalendar

## Block Description start

Users can share their calendars with other users. They can then view and book meetings when others are available, avoiding schedule clashes.

## Getting Started
N/A

### Prerequisites
N/A

### Git Structure
N/A

### Installing
N/A

## Running the tests

N/A
## CI/CD Details
N/A

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).