## Building Blocks React Native Mobile -  Notifications

Building Blocks - React Native Master App - Notifications

## Getting Started

### Prerequisites

### Git Structure

### Installing

## Running the tests

## CI/CD Details

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).