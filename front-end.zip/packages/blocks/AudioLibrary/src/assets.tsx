export const imgPasswordVisible = require("../assets/ic_password_visible.png");
export const imgPasswordInVisible = require("../assets/ic_password_invisible.png");
export const back = require("../assets/back.png");
export const audioIcon = require("../assets/audio.png");
export const audioBg = require("../assets/audiobg.png");
export const sound = require("../assets/sound.png");
export const picture = require("../assets/picture.png");
export const trackFull = require("../assets/track.png");
