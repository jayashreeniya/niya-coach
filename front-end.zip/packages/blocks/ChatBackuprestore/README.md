## Building Blocks React Native Mobile -  ChatBackuprestore

Building Blocks - React Native Master App - ChatBackuprestore

## Getting Started
N/A

### Prerequisites
N/A

### Git Structure
N/A

### Installing
N/A

## Running the tests
N/A

## CI/CD Details
N/A

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).