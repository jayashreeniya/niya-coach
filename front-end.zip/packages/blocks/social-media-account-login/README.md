## Building Blocks React Native Mobile - Social Media Account Log In

Building Blocks - React Native Master App - Social Media Account Log In

## Getting Started

React Native Social Authentication: https://rnfirebase.io/auth/social-auth

### Prerequisites

### Git Structure

### Installing

## Running the tests

## CI/CD Details

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).



