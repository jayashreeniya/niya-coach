export const imgPasswordVisible = require("../assets/ic_password_visible.png");
export const imgPasswordInVisible = require("../assets/ic_password_invisible.png");
export const imgBottomMsg = require("../assets/imgBottomMsg.png");
export const journeyDashboardbg = require("../assets/JourneyDashboardbg.png");