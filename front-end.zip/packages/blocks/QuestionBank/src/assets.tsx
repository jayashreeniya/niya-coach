export const imgPasswordVisible = require("../assets/ic_password_visible.png");
export const imgPasswordInVisible = require("../assets/ic_password_invisible.png");
export const header2bg = require("../assets/backgrndSecondQue.png");
export const imgSmile = require("../assets/imgSmile.png");
export const imgweareglad = require("../assets/we_are_glad.png");
export const imgnavClose = require("../assets/imagenav_close.png");
export const imgNegativewhale = require("../assets/negative_whale.png");

